using System;
using System.IO;
using System.Text;
using LaserVision;

public static class AudioCodecTests
{
    static int checks;
    static void Assert(bool value,string message) { checks++; if(!value) throw new Exception(message); }
    static void Near(float actual,float expected,string message) { Assert(Math.Abs(actual-expected)<0.0001f,message); }
    static MemoryStream Wave(int format,int bits,int channels,byte[] data,bool junk,bool extensible)
    {
        MemoryStream stream=new MemoryStream(); BinaryWriter w=new BinaryWriter(stream,Encoding.ASCII,true);
        w.Write(Encoding.ASCII.GetBytes("RIFF")); w.Write(0); w.Write(Encoding.ASCII.GetBytes("WAVE"));
        if(junk) { w.Write(Encoding.ASCII.GetBytes("JUNK")); w.Write(3); w.Write(new byte[] {1,2,3,0}); }
        w.Write(Encoding.ASCII.GetBytes("fmt ")); w.Write(extensible?40:16); w.Write((ushort)(extensible?0xfffe:format));
        w.Write((ushort)channels); w.Write(48000); w.Write(48000*channels*bits/8); w.Write((ushort)(channels*bits/8)); w.Write((ushort)bits);
        if(extensible) { w.Write((ushort)22); w.Write((ushort)bits); w.Write(0); w.Write((ushort)format); w.Write(new byte[14]); }
        w.Write(Encoding.ASCII.GetBytes("data")); w.Write(data.Length); w.Write(data); if((data.Length&1)!=0)w.Write((byte)0);
        long size=stream.Length; stream.Position=4;w.Write((int)(size-8));stream.Position=0;return stream;
    }
    static byte[] Bytes(Action<BinaryWriter> action) { MemoryStream s=new MemoryStream(); BinaryWriter w=new BinaryWriter(s);action(w);return s.ToArray(); }
    static void Throws(Action action,string message) { bool threw=false;try {action();}catch(InvalidDataException){threw=true;} Assert(threw,message); }
    public static void Main()
    {
        WavePcm wav=WavePcm.Read(Wave(1,8,1,new byte[]{0,128,255},true,false));
        Near(wav.Samples[0],-1,"PCM8 min");Near(wav.Samples[1],0,"PCM8 zero");Near(wav.Samples[2],127/128f,"PCM8 max");Assert(wav.Frames==3&&wav.Rate==48000,"PCM8 header");
        wav=WavePcm.Read(Wave(1,16,2,Bytes(delegate(BinaryWriter w){w.Write((short)-32768);w.Write((short)32767);w.Write((short)0);w.Write((short)16384);}),false,false));
        Assert(wav.Channels==2&&wav.Frames==2,"stereo frame count");Near(wav.Samples[0],-1,"PCM16 min");Near(wav.Samples[1],32767/32768f,"PCM16 max");Near(wav.Samples[3],0.5f,"PCM16 stereo interleaved");
        wav=WavePcm.Read(Wave(1,24,1,new byte[]{0,0,128,255,255,127,0,0,0},false,false));
        Near(wav.Samples[0],-1,"PCM24 sign extension");Near(wav.Samples[1],1,"PCM24 positive max");Near(wav.Samples[2],0,"PCM24 zero");
        wav=WavePcm.Read(Wave(1,32,1,Bytes(delegate(BinaryWriter w){w.Write(int.MinValue);w.Write(int.MaxValue);w.Write(0);}),false,true));
        Near(wav.Samples[0],-1,"PCM32 min extensible");Near(wav.Samples[1],1,"PCM32 max extensible");Near(wav.Samples[2],0,"PCM32 zero extensible");
        wav=WavePcm.Read(Wave(3,32,1,Bytes(delegate(BinaryWriter w){w.Write(0.25f);w.Write(-0.5f);w.Write(float.NaN);w.Write(float.PositiveInfinity);w.Write(2f);}),false,false));
        Near(wav.Samples[0],0.25f,"float32 positive");Near(wav.Samples[1],-0.5f,"float32 negative");Near(wav.Samples[2],0,"float32 NaN sanitized");Near(wav.Samples[3],0,"float32 infinity sanitized");Near(wav.Samples[4],1,"float32 range clamped");
        Throws(delegate {WavePcm.Read(Wave(6,16,1,new byte[4],false,false));},"unsupported codec rejected");
        Throws(delegate {WavePcm.Read(Wave(3,16,1,new byte[4],false,false));},"invalid float bit width rejected");
        Throws(delegate {WavePcm.Read(Wave(1,16,2,new byte[6],false,false));},"partial stereo frame rejected");
        Throws(delegate {WavePcm.Read(new MemoryStream(new byte[4]));},"truncated header rejected");
        MemoryStream malformed=Wave(1,16,1,new byte[4],false,false);malformed.SetLength(malformed.Length-1);
        Throws(delegate {WavePcm.Read(malformed);},"truncated data rejected");
        wav=new WavePcm {Rate=48000,Channels=1,Samples=new float[4800]};for(int i=0;i<wav.Frames;i++)wav.Samples[i]=(float)Math.Sin(i*0.31);
        WavePcm loop=wav.Seamless(0.01);Assert(loop.Frames==4320,"crossfade loop frame count");Near(loop.Samples[0],wav.Samples[4320],"loop seam begins with contiguous tail");Near(loop.Samples[loop.Frames-1],wav.Samples[4319],"loop seam ends with adjacent source sample");
        WavePcm slice=wav.Slice(0.01,0.03);Assert(slice.Frames==1440,"sample slice duration");Near(slice.Samples[0],wav.Samples[480],"sample slice start");
        wav.Normalize(0.7f,true);Near(wav.Samples[0],0,"fade attack");Near(wav.Samples[wav.Frames-1],0,"fade release");
        float peak=0;foreach(float x in wav.Samples)peak=Math.Max(peak,Math.Abs(x));Assert(peak<=0.7001f,"normalization respects peak");
        string temp=Path.Combine(Path.GetTempPath(),"chosen-codec-"+Guid.NewGuid().ToString("N")+".wav");wav.Write16(temp);WavePcm round=WavePcm.Read(temp);Assert(round.Frames==wav.Frames&&round.Rate==wav.Rate,"WAV write/read header roundtrip");Near(round.Samples[600],wav.Samples[600],"PCM16 sample roundtrip");File.Delete(temp);
        foreach(string file in Directory.Exists(@"mod\Audio") ? Directory.GetFiles(@"mod\Audio","*.wav") : new string[0])
        {
            WavePcm clip=WavePcm.Read(file);Assert(clip.Channels==1&&clip.Rate==48000&&clip.Frames>0,"prepared clip decodes: "+Path.GetFileName(file));
            foreach(float sample in clip.Samples) if(float.IsNaN(sample)||float.IsInfinity(sample)||Math.Abs(sample)>1)throw new Exception("invalid prepared sample");
        }
        Console.WriteLine("PASS: "+checks+" WAV codec/prepared-audio checks");
    }
}

