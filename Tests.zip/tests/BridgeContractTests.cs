// Adapter contract tests against minimal test doubles. These execute the real
// ZandatsuBridge source, but do not validate Unity, Nomad, or Zandatsu at runtime.
using System;
using System.Collections.Generic;
using LaserVision;
using UnityEngine;
using ThunderRoad;

namespace UnityEngine
{
    public class Object
    {
        public static implicit operator bool(Object value) { return !ReferenceEquals(value, null); }
    }
    public class GameObject : Object
    {
        private readonly List<Component> components = new List<Component>();
        public bool activeInHierarchy = true;
        public readonly Transform transform;
        public GameObject() { transform = new Transform(); Attach(transform); }
        public T Attach<T>(T component) where T : Component { component.gameObject = this; components.Add(component); return component; }
        public Component GetComponent(Type type) { return components.Find(delegate(Component c) { return type.IsAssignableFrom(c.GetType()); }); }
    }
    public class Component : Object
    {
        public GameObject gameObject;
        public Transform transform { get { return gameObject.transform; } }
    }
    public class Transform : Component
    {
        public Transform parent;
        public Component GetComponent(Type type) { return gameObject.GetComponent(type); }
    }
    public class Collider : Component { }
    public struct Vector3
    {
        public float x,y,z;
        public Vector3(float x,float y,float z) { this.x=x; this.y=y; this.z=z; }
        public float sqrMagnitude { get { return x*x+y*y+z*z; } }
        public void Normalize() { float n=(float)Math.Sqrt(sqrMagnitude); if(n>0) { x/=n; y/=n; z/=n; } }
    }
    public static class Time { public static float unscaledTime; }
    public static class Debug
    {
        public static readonly List<string> Logs = new List<string>();
        public static void Log(object value) { Logs.Add(value.ToString()); }
        public static void LogWarning(object value) { Logs.Add(value.ToString()); }
    }
}

namespace ThunderRoad
{
    public class ThunderScript { }
    public class Creature : Component { public bool isPlayer; public bool MeetsHealth = true; }
    public class RagdollPart : Component { }
    public class Item : Component { }
    public static class ModManager
    {
        public class ModData { public List<ThunderScript> thunderScripts = new List<ThunderScript>(); }
        public static List<ModData> loadedMods = new List<ModData>();
    }
}

namespace Zandatsu
{
    public class SlicedPiece : Component
    {
        public bool busy;
        public bool dead;
        public bool IsDead { get { return dead; } }
    }
    public class PieceBody : Component { public SlicedPiece piece; }
    public class ZandatsuScript : ThunderScript
    {
        // The names, visibility, and types below deliberately reproduce the
        // private contract inspected from the user's Zandatsu 0.7.0 DLL.
        private struct PendingCut
        {
            public Creature creature;
            public Vector3 point,normal,bladeVelocity;
            public RagdollPart hitPart;
            public Item item;
            public float fire;
        }
        public sealed class Capture
        {
            public Creature Creature;
            public Vector3 Point,Normal,Velocity;
            public RagdollPart Part;
            public Item Item;
            public float Fire;
        }
        public static bool Enabled = true, RecutPieces = true, AllowGore = true;
        public static bool AcceptClaim = true, AcceptPieceCut = true, ThrowClaim;
        private static bool GoreAllowed { get { return AllowGore; } }
        private static bool HealthAllows(Creature creature, float damage) { return creature.MeetsHealth; }
        public int Claims, PieceCuts, LastHitBody;
        public SlicedPiece LastPiece;
        public Capture Last;
        private bool Claim(PendingCut cut)
        {
            if (ThrowClaim) throw new InvalidOperationException("simulated claim failure");
            Claims++;
            Last = new Capture { Creature=cut.creature,Point=cut.point,Normal=cut.normal,Velocity=cut.bladeVelocity,Part=cut.hitPart,Item=cut.item,Fire=cut.fire };
            return AcceptClaim;
        }
        private void CutPiece(SlicedPiece piece, Vector3 point, Vector3 normal, Vector3 velocity, Item item, int hitBody, float fire)
        {
            PieceCuts++; LastPiece=piece; LastHitBody=hitBody;
            Last=new Capture { Point=point,Normal=normal,Velocity=velocity,Item=item,Fire=fire };
            piece.busy=AcceptPieceCut;
        }
    }
}

public static class BridgeContractTests
{
    private static int checks;
    private sealed class UnrelatedScript : ThunderScript { }
    private static void Assert(bool value,string message) { checks++; if(!value) throw new Exception(message); }
    private static void Near(float value,float expected,string message) { Assert(Math.Abs(value-expected)<0.00001,message); }
    private static Vector3 V(float x,float y,float z) { return new Vector3(x,y,z); }
    private static Creature Creature() { return new GameObject().Attach(new Creature()); }
    private static Collider Collider() { return new GameObject().Attach(new Collider()); }
    private static bool Cut(ZandatsuBridge bridge,Collider hit,Creature creature,bool burn)
    { return bridge.TryCut(hit,creature,null,V(1,2,3),V(0,4,0),V(5,6,7),burn); }
    private static void NextRefresh() { Time.unscaledTime += 3; }
    public static void Main()
    {
        ModManager.loadedMods.Clear();
        ZandatsuBridge bridge = new ZandatsuBridge();
        Assert(!bridge.Ready,"absent mod must disable cutting");
        Assert(bridge.Status.IndexOf("not loaded")>=0,"absent mod status useful");
        Creature creature=Creature(); Collider collider=Collider();
        Assert(!Cut(bridge,collider,creature,true),"absent mod rejects cuts gracefully");
        Assert(bridge.PieceTarget(collider)==null,"absent mod has no detached target");

        ModManager.ModData unrelated = new ModManager.ModData();
        unrelated.thunderScripts.Add(null); unrelated.thunderScripts.Add(new UnrelatedScript());
        ModManager.loadedMods.Add(null); ModManager.loadedMods.Add(unrelated);
        ModManager.ModData intended = new ModManager.ModData();
        Zandatsu.ZandatsuScript script = new Zandatsu.ZandatsuScript();
        intended.thunderScripts.Add(script); ModManager.loadedMods.Add(intended);
        NextRefresh(); Assert(bridge.Ready,"find exact script among null and unrelated mod entries");
        Assert(bridge.Status.IndexOf("ready")>=0,"ready status after binding");
        RagdollPart part=new GameObject().Attach(new RagdollPart());
        Assert(bridge.TryCut(collider,creature,part,V(1,2,3),V(0,4,0),V(5,6,7),true),"valid cut accepted");
        Assert(script.Claims==1,"claim called exactly once");
        Assert(ReferenceEquals(script.Last.Creature,creature),"PendingCut creature preserved");
        Assert(ReferenceEquals(script.Last.Part,part),"PendingCut hitPart preserved");
        Near(script.Last.Point.x,1,"point x"); Near(script.Last.Point.y,2,"point y"); Near(script.Last.Point.z,3,"point z");
        Near(script.Last.Normal.y,1,"plane normal normalized"); Near(script.Last.Normal.x,0,"normal x");
        Near(script.Last.Velocity.x,5,"velocity x"); Near(script.Last.Velocity.y,6,"velocity y"); Near(script.Last.Velocity.z,7,"velocity z");
        Near(script.Last.Fire,1,"burn true maps fire to one"); Assert(script.Last.Item==null,"laser has no physical sword item");
        Assert(Cut(bridge,collider,creature,false),"non-burning valid cut accepted"); Near(script.Last.Fire,0,"burn false maps fire to zero");

        int claims=script.Claims;
        Zandatsu.ZandatsuScript.Enabled=false;
        Assert(!bridge.Ready && !Cut(bridge,collider,creature,true),"disabled Zandatsu rejected");
        Assert(bridge.Status.IndexOf("disabled")>=0,"disabled status useful");
        Zandatsu.ZandatsuScript.Enabled=true; Zandatsu.ZandatsuScript.AllowGore=false;
        Assert(!bridge.Ready && !Cut(bridge,collider,creature,true),"gore settings reject cuts");
        Zandatsu.ZandatsuScript.AllowGore=true; creature.MeetsHealth=false;
        Assert(!Cut(bridge,collider,creature,true),"health threshold respected"); creature.MeetsHealth=true;
        creature.isPlayer=true; Assert(!Cut(bridge,collider,creature,true),"player excluded"); creature.isPlayer=false;
        creature.gameObject.activeInHierarchy=false; Assert(!Cut(bridge,collider,creature,true),"inactive creature excluded"); creature.gameObject.activeInHierarchy=true;
        Assert(!Cut(bridge,collider,null,true),"null creature rejected");
        Assert(!bridge.TryCut(collider,creature,part,V(float.NaN,0,0),V(0,1,0),V(1,0,0),true),"NaN contact rejected");
        Assert(!bridge.TryCut(collider,creature,part,V(0,0,0),V(0,0,0),V(1,0,0),true),"zero normal rejected");
        Assert(!bridge.TryCut(collider,creature,part,V(0,0,0),V(0,1,0),V(float.PositiveInfinity,0,0),true),"infinite velocity rejected");
        Assert(script.Claims==claims,"rejected inputs never reach Claim");
        Zandatsu.ZandatsuScript.AcceptClaim=false;
        Assert(!Cut(bridge,collider,creature,true),"Claim rejection propagated"); Zandatsu.ZandatsuScript.AcceptClaim=true;

        GameObject pieceObject=new GameObject();
        Zandatsu.SlicedPiece piece=pieceObject.Attach(new Zandatsu.SlicedPiece());
        GameObject bodyObject=new GameObject(); bodyObject.transform.parent=pieceObject.transform;
        bodyObject.Attach(new Zandatsu.PieceBody { piece=piece });
        GameObject childObject=new GameObject(); childObject.transform.parent=bodyObject.transform;
        Collider child=childObject.Attach(new Collider());
        Assert(ReferenceEquals(bridge.PieceTarget(child),piece),"child collider resolves PieceBody identity");
        Assert(bridge.IsDetachedPiece(child),"detached piece detected");
        Collider direct=pieceObject.Attach(new Collider());
        Assert(ReferenceEquals(bridge.PieceTarget(direct),piece),"direct SlicedPiece component detected");
        Assert(bridge.PieceTarget(null)==null,"null collider handled");
        creature.MeetsHealth=false;
        Assert(Cut(bridge,child,creature,true),"detached piece takes precedence over creature hierarchy and health");
        Assert(script.PieceCuts==1 && ReferenceEquals(script.LastPiece,piece),"correct piece sent to CutPiece");
        Near(script.Last.Fire,1,"piece burn propagated"); Near(script.Last.Normal.y,1,"piece normal normalized");
        Assert(script.LastHitBody==-1 && script.Last.Item==null,"piece cut uses no physical body or sword");
        Assert(piece.busy,"accepted recut marked busy");
        Assert(!Cut(bridge,child,null,true),"busy piece cannot be recut"); piece.busy=false;
        Zandatsu.ZandatsuScript.RecutPieces=false;
        Assert(!Cut(bridge,child,null,true),"recut option respected"); Zandatsu.ZandatsuScript.RecutPieces=true;
        piece.dead=true; Assert(!Cut(bridge,child,null,true),"dead piece rejected"); piece.dead=false;
        pieceObject.activeInHierarchy=false; Assert(!Cut(bridge,child,null,true),"inactive piece rejected"); pieceObject.activeInHierarchy=true;
        Assert(script.PieceCuts==1,"rejected piece requests never reach CutPiece");
        Zandatsu.ZandatsuScript.AcceptPieceCut=false;
        Assert(!Cut(bridge,child,null,false),"CutPiece declining busy transition propagates rejection");
        Near(script.Last.Fire,0,"piece non-burning flag propagated"); Zandatsu.ZandatsuScript.AcceptPieceCut=true;

        creature.MeetsHealth=true;
        Zandatsu.ZandatsuScript.ThrowClaim=true;
        Assert(!Cut(bridge,collider,creature,true),"reflection target exception contained");
        Assert(Debug.Logs.Exists(delegate(string s) { return s.IndexOf("simulated claim failure")>=0; }),"inner exception reported");
        Zandatsu.ZandatsuScript.ThrowClaim=false;
        Assert(Cut(bridge,collider,creature,true),"cutting can recover from request failure");
        ModManager.loadedMods.Clear(); NextRefresh();
        Assert(!bridge.Ready && !Cut(bridge,collider,creature,true),"unloading mod removes cached script");
        Console.WriteLine("PASS: "+checks+" bridge contract checks (test doubles; no game-runtime validation)");
    }
}
