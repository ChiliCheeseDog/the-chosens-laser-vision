using System;
using LaserVision;
class PowerStateTests
{
    static int checks;
    static void Check(bool condition,string message) { checks++;if(!condition)throw new Exception(message); }
    static void Main()
    {
        var state=new BeamPowerState();
        for(int i=0;i<4;i++)state.Step(true,true,true,0.1);
        Check(!state.Overdrive && Math.Abs(state.Charge-0.8f)<0.001,"Four tenths charges but does not fire");
        state.Step(true,true,true,0.1);Check(state.Overdrive && state.Charge==1,"Half second activates");
        state.Step(true,false,true,0.01);Check(!state.Overdrive && state.Charge==0,"Release grip returns to ordinary beam");
        state.Step(true,true,true,0.1);Check(!state.Overdrive && state.Charge<0.3,"Regrip starts fresh charge");
        state.Step(false,true,true,0.1);Check(state.Charge==0,"Trigger release resets charge");
        state.Step(true,true,false,0.1);Check(!state.Overdrive && state.Charge==0,"Setting disabled gates overdrive");
        state.Step(true,true,true,30);Check(!state.Overdrive,"Frame stall cannot activate immediately");
        state.Step(false,false,true,0);state.Step(true,true,true,double.NaN);Check(state.Charge==0,"NaN rejected");
        state.Step(true,true,true,double.PositiveInfinity);Check(state.Charge==0,"Infinity rejected");
        state.Step(true,true,true,-0.1);Check(state.Charge==0,"Negative time rejected");
        for(int i=0;i<50;i++)state.Step(true,true,true,0.01);
        Check(state.Overdrive,"High refresh-rate accumulated half second activates");
        for(int i=0;i<200;i++)state.Step(true,true,true,0.02);
        Check(state.Charge==1,"Sustained charge remains capped");
        Console.WriteLine("PASS: "+checks+" overdrive state checks");
    }
}
