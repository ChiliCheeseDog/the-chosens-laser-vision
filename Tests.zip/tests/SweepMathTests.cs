using System;
using LaserVision;

public static class SweepMathTests
{
    private static int checks;
    private static SweepVector V(double x, double y, double z) { return new SweepVector(x,y,z); }
    private static void Assert(bool condition, string message) { checks++; if (!condition) throw new Exception(message); }
    private static void Near(double actual, double expected, string message) { Assert(Math.Abs(actual-expected)<1e-6, message); }
    private static bool Create(SweepVector a, SweepVector b, out SweepPlan p)
    { return BeamSweepMath.TryCreate(V(0,0,0),a,a*5,V(0,0,0),b,b*5,0.01,15,0.25,45,0.25,24,out p); }
    public static void Main()
    {
        SweepPlan p;
        Assert(Create(V(0,0,1), V(0.1,0,1),out p),"horizontal sweep must slash");
        Near(p.PlaneNormal.X,0,"horizontal cut normal X"); Near(p.PlaneNormal.Y,1,"horizontal cut normal Y"); Near(p.PlaneNormal.Z,0,"horizontal cut normal Z");
        Assert(SweepVector.Dot(p.Direction,V(1,0,0))>0.99,"swing tangent points right");
        Near(SweepVector.Dot(p.PlaneNormal,V(0,0,1)),0,"normal perpendicular to first ray");
        Near(SweepVector.Dot(p.PlaneNormal,V(0.1,0,1)),0,"normal perpendicular to last ray");
        Assert(Create(V(0,0,1),V(0,0.1,1),out p),"vertical sweep must slash"); Near(p.PlaneNormal.X,-1,"vertical cut normal X");
        Assert(Create(V(0,0,1),V(0.1,0.1,1),out p),"diagonal sweep must slash");
        Near(p.PlaneNormal.X,-Math.Sqrt(0.5),"diagonal normal X"); Near(p.PlaneNormal.Y,Math.Sqrt(0.5),"diagonal normal Y");
        Assert(Create(V(0.1,0.1,1),V(0,0,1),out p),"reverse sweep must slash"); Assert(p.PlaneNormal.X>0 && p.PlaneNormal.Y<0,"reverse sweep reverses plane orientation");
        Assert(!Create(V(0,0,1),V(0,0,1),out p),"stationary beam cannot define a slash");
        Assert(!Create(V(0,0,1),V(0.00001,0,1),out p),"tremor cannot slash");
        Assert(!Create(V(0,0,0),V(0.1,0,1),out p),"zero direction rejected");
        Assert(!Create(V(double.NaN,0,1),V(0.1,0,1),out p),"NaN direction rejected");
        Assert(!Create(V(0,0,1),V(1,0,0),out p),"large tracking rotation reset rejected");
        Assert(!BeamSweepMath.TryCreate(V(0,0,0),V(0,0,1),V(0,0,5),V(0.1,0,0),V(0,0,1),V(0.1,0,5),0.01,15,0.25,45,0.25,24,out p),"head translation alone must not slash");
        Assert(!BeamSweepMath.TryCreate(V(0,0,0),V(0,0,1),V(0,0,5),V(4,0,0),V(0.1,0,1),V(4.1,0,5),0.01,15,0.25,45,0.25,24,out p),"teleport must reset sweep");
        Assert(!BeamSweepMath.TryCreate(V(0,0,0),V(0,0,1),V(0,0,5),V(0,0,0),V(0.1,0,1),V(0.5,0,5),0,15,0.25,45,0.25,24,out p),"zero dt rejected");
        Assert(!BeamSweepMath.TryCreate(V(0,0,0),V(0,0,1),V(0,0,5),V(0,0,0),V(0.1,0,1),V(0.5,0,5),0.5,15,0.25,45,0.25,24,out p),"frame stall resets sweep");
        Assert(Create(V(0,0,1),V(0.5,0,1),out p),"wide valid sweep"); Assert(p.SampleCount==24,"ray sampling must cap cost");
        Near(p.PlanePoint.X,1.25,"plane anchors at contact midpoint"); Near(p.PlanePoint.Z,5,"plane depth at contact midpoint");
        SweepVector mid = BeamSweepMath.DirectionAt(V(0,0,1),V(1,0,1),0.5);
        Near(mid.Length,1,"slerp ray remains unit"); Near(Math.Atan2(mid.X,mid.Z)*180/Math.PI,22.5,"slerp covers angular midpoint");
        Near(BeamSweepMath.OriginAt(V(0,0,0),V(2,0,0),0.25).X,0.5,"origin interpolation");
        Near(BeamSweepMath.DirectionAt(V(0,0,1),V(1,0,1),-1).X,0,"interpolation clamps low");
        Near(BeamSweepMath.DirectionAt(V(0,0,1),V(1,0,1),2).X,Math.Sqrt(0.5),"interpolation clamps high");
        Console.WriteLine("PASS: " + checks + " sweep-math checks");
    }
}
